

<?php $__env->startSection('content'); ?>


<div class="principal">
  <aside class="col-12 col-md-3 p-0">
        <nav class="navbar navbar-expand flex-md-column flex-row align-items-start">
            <h2>Entradas</h2>
            <div class="collapse navbar-collapse">
                <ul class="flex-md-column flex-row navbar-nav w-100 justify-content-between">
                <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item">
                        <a class="nav-link pl-0" href="#<?php echo e($entrada->titulo); ?>"><?php echo e($entrada->titulo); ?></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </nav>
    </aside>
  <section>
  <?php $__currentLoopData = $entradas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <div class="card-header" id="<?php echo e($entrada->titulo); ?>">
      <?php echo e($entrada->titulo); ?>

    </div>
    <div class="card-body">
    <?php if(isset( $entrada->imagen )): ?>
        <p> <img src="<?php echo e(asset('img/'.$entrada->imagen)); ?>" alt="" class="img-responsive img-cont"/></p>
    
    <?php else: ?>
        <p> </p>
    <?php endif; ?>
      <p class="card-text"><small>Ultima actualización: <?php echo e($entrada->updated_at); ?></small></p>
      <p class="card-text"><?php echo e($entrada->descripcion); ?> </p>
    </div>
  </div>
  <hr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\palpa\Documents\Proyectos\pruebaGK\resources\views/principal/visualizar.blade.php ENDPATH**/ ?>