

<?php $__env->startSection('content'); ?>
    <div class="form-div"> 

        <div class="row">
            <div class="col-lg-12 margin-tb">
                <div class="pull-left">
                    <h2>Agregar nueva entrada</h2>
                </div>
            </div>
        </div>

        <form method="POST" action="<?php echo e(route('entradas.store')); ?>"  role="form" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <!-- <?php echo e(csrf_field()); ?> -->
    <div class="form-group">
        <label for="titulo">Título</label>
        <input type="text" class="form-control input-sm" id="titulo" name="titulo" placeholder="Ingrese título de entrada">
    </div>
    <div class="form-group">
        <label for="descripcion">Descripción</label>
        <textarea class="form-control" id="descripcion" name="descripcion" rows="6"></textarea>
    </div>
    <div class="form-group">
        <label for="imagen">Imagen</label>
        <input id="imagen" name="imagen" type="file" accept="image/*"/>
    </div>
    <button type="submit" class="btn btn-primary">Guardar</button>
    
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\palpa\Documents\Proyectos\pruebaGK\resources\views/principal/formulario.blade.php ENDPATH**/ ?>