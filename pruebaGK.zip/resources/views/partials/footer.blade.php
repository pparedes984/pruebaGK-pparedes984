 <footer class="container fluid">
    <div class="row">
        <div class="col-md-4">
            <h3>Prueba GK</h3>
            <p>Este es el aplicativo solicitado para demostrar habilidades y conocimiento de desarrollo.</p>
        </div>
        <div class="col-md-4">
            <h3>Desarrollado por:</h3>
            <div class="author info">
                Copyright&copy; 2020<br /><p>Paul Paredes</p>
            </div>
        </div>
        <div class="col-md-4">
            <h3>Siguenos</h3>
            <ul class="redes">
                <li>
                    <a href="mailto:pparedes984@puce.edu.ec"><i class="fa fa-envelope-square fa-2x"></i></a>
                </li>
                <li>
                    <a href="https://www.linkedin.com/in/paul-alejandro-paredes-sandoval-a65b641b5/"><i class="fa fa-linkedin-square fa-2x"></i></a>
                </li>
                <li>
                    <a href="https://github.com/pparedes984"><i class="fa fa-github-square fa-2x"></i></a>
                </li>
                
            </ul>
            
        </div>
    </div>
</footer>